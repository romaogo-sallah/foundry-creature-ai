export const RUNTIME_VERSION = '0.36.1';
