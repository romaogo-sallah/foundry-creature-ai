// Describe the selected action, without inventing numeric advantages or exposing
// target statistics. These are presentation templates, not additional AI rules.
export function actionIntent({profileId,choice,state={}}){
  if(!choice||choice.kind==='endTurn')return null;
  if(choice.features?.confused)return ['strike','castSpell'].includes(choice.kind)?'Get away from me!':choice.kind==='hover'?'The confused creature beats its wings to stay aloft.':'The confused creature blunders toward its chosen target, readying an attack.';
  const animal=profileId==='wolf',enemy=state.enemies?.find(enemy=>enemy.id===choice.targetId);
  const retreat=choice.intent==='retreat'||choice.features?.retreat,again=(state.attacksMade??0)%2===1;
  if(retreat)return animal?'A frightened whine; the wolf looks for a way out.':'This fight is lost. Get out while we can!';
  if(profileId.startsWith('vampire-')){
    if(choice.kind==='castSpell')return ({dominate:'Look into my eyes. Your companions are your enemies now.',haste:'Move swiftly. Keep them occupied for me.',blur:'Let their blows pass through shadows.',invisibility:'You cannot strike what you cannot see.', 'fire-shield':'Come closer, if you dare.','wall-of-fire':'Let the flames divide them.','floating-flame':'Run. The fire will follow.','fireball':'Your formation will be your undoing.','lightning-bolt':'Stand together. Make this easy.','vision-of-death':'Look upon the end that awaits you.'})[choice.spellSlug]??'Your resistance is wearing thin.';
    if(choice.kind==='drinkBlood')return 'Your blood will restore me.';
    if(choice.kind==='grab')return 'Hold still. The others are closing in.';
    if(choice.kind==='mistFly'||choice.kind==='escapeScene')return 'The vampire dissolves into mist and drifts toward a way out.';
    if(choice.kind==='vampireForm')return choice.form==='bat'?'The vampire becomes a giant bat and spreads its wings.':'The mist gathers into the vampire’s familiar shape.';
    if(choice.kind==='sustainSpell')return 'Keep moving. The flames are following you.';
    if(choice.kind==='raiseFireShield')return 'A shield of fire rises between the vampire and its foes.';
    if(['vampireEquip','vampireStow'].includes(choice.kind))return 'A different weapon for a different opening.';
    if(choice.kind==='fly')return 'The giant bat wheels toward its foe.';
  }
  switch(choice.kind){
    case 'fly':{
      const flyer=profileId.startsWith('manticore-')?'manticore':'eagle';
      return choice.features?.flightRetreat?'The flyer pulls away, beyond its prey’s reach.':choice.intent==='climb before hunting'?`The ${flyer} climbs, watching the battlefield below.`:choice.features?.hover?`The ${flyer} beats its wings, watching for an opening.`:choice.intent==='survey from safe altitude'?`The ${flyer} circles high above, watching its prey.`:choice.features?.diveSetup?`The ${flyer} climbs, watching for a chance to swoop.`:`The ${flyer} wheels through the air toward its prey.`;
    }
    case 'eagleDive':return 'Wings fold; the eagle dives with talons extended.';
    case 'spikeVolley':return choice.mode==='split'?'The manticore whips its tail, scattering spikes at the clustered prey.':'The manticore aims two spikes to pin its prey in place.';
    case 'sustainSpell':return 'Keep laughing. I am not finished with you.';
    case 'gaze':return 'Look at me. Let the blue light fill your mind.';
    case 'castSpell':return choice.spellSlug==='vampiric-feast'?'Your strength will sustain me.':choice.spellSlug==='laughing-fit'?'Laugh for me. Let your guard slip.':choice.spellSlug==='stupefy'?'Let us quiet those clever thoughts.':choice.spellSlug==='blindness'?'Find your way through the dark.':choice.spellSlug==='void-warp'?'Feel your strength ebb away.':choice.features?.preparation?'Come closer, longshanks. Watch your feet!':choice.spellSlug==='breathe-fire'?'All together? Good. More things to burn!':choice.spellSlug==='grease'?'Try running over this, longshanks!':choice.spellSlug==='tangle-vine'?'Stay there. The vines have you!':'Burn, burn, burn!';
    case 'goblinScuttle':return 'Make room! I have a better spot!';
    case 'strike':
      if(profileId.startsWith('manticore-'))return choice.features?.ranged?'The manticore launches a spike from above.':'The manticore lashes out, keeping its wings ready to pull away.';
      if(animal)return choice.packAttack?'A sharp bark; the wolf closes in with its pack.':enemy?.prone?'The wolf lunges at the fallen prey.':again?'Teeth flash as the wolf presses its attack.':'A low growl; the wolf bares its teeth and lunges.';
      if(profileId==='kobold-scout')return choice.features?.groupGoal==='kite'?'Shoot, then keep our distance. Keep them chasing!':choice.features?.groupGoal==='swarm'?'Keep it busy. We are closing in!':enemy?.prone||enemy?.offGuard?'You left yourself open. This is my chance!':enemy?.stealthChance>0?'If they lost sight of me, this is my chance!':'Hold still. I only need one good opening.';
      if(choice.features?.frontline&&state.style?.enabled&&!state.frontlineEngaged)return "Let's see how tough you really are!";
      if(enemy?.prone)return 'Stay down. You are easier to reach there!';
      if(choice.features?.ranged)return 'You cannot stay out of my reach forever!';
      return again?'I am not finished with you yet!':'There is my opening. Have a taste of this!';
    case 'knockdown':return 'The wolf snaps low, trying to drag its prey off its feet.';
    case 'trip':return 'On your back! Then you get the hook.';
    case 'sweepingHook':return 'Down you go, and here comes the hook!';
    case 'reactiveStrike':return 'You left an opening. Not so fast!';
    case 'stand':return animal?'The wolf plants its paws and struggles upright.':'I am not staying down!';
    case 'escape':return animal?'The wolf twists and strains against its bonds.':'Let go! I am breaking free!';
    case 'hide':return animal?'The wolf lowers itself into cover and waits.':state.behavior?.selection?.planId==='lay-low'?'Stay low. Make it lose sight of us.':'Lose sight of me, and you will regret it.';
    case 'seek':return animal?'The wolf sniffs the air and searches the place where its prey vanished.':'Where did you go? There must be a sign of you here.';
    case 'sneak':return animal?'The wolf slips quietly between hiding places.':'Quietly now. Find an opening before they spot me.';
    case 'scamper':return 'Too close! Catch me if you can!';
    case 'reload':return 'One more bolt. Keep them busy!';
    case 'bellow':return 'Get moving! Close in on them together!';
    case 'regrip':return 'Both hands. Now I am ready for you!';
    case 'drawJavelin':return 'Too far away? I have something for that.';
    case 'drawRefuse':return 'This will do. Now hold still!';
    case 'drawMelee':return 'Close enough. Time for the axe!';
    case 'drawSword':return choice.features?.groupGoal==='melee'?'No bolts left. Blades out!':choice.features?.groupGoal==='swarm'?'Swords out! Get around it together!':'Too close for the bow. Out comes the blade!';
    case 'stow':return 'Put this away. I need my other hand.';
    case 'stowSword':return 'Back to the bow. Keep your distance.';
    case 'gripBow':return 'Steady the bow. Find the shot.';
    case 'stride':case 'step':case 'crawl':case 'escapeStride':
      if(choice.features?.avoidance)return animal?'The wolf backs away, guarding its wounds.':'Too dangerous here. I need some distance!';
      if(choice.features?.defensiveSetup)return 'Into cover. Let them come to me.';
      if(choice.features?.casterPosition)return 'A little room. A better place to cast.';
      if(choice.features?.groupGoal==='melee')return 'Close in. I can still fight with this blade!';
      if(choice.features?.groupGoal==='swarm')return 'Around the other side! It cannot face all of us.';
      if(choice.features?.groupGoal==='kite')return 'Fall back and keep shooting. Make them come to us!';
      if(choice.features?.investigation)return animal?'The wolf sniffs around, searching for a way to its prey.':'I will look from over there. You cannot hide forever.';
      if(choice.features?.rangedFollowUp)return 'Closer. I need a better angle for this throw.';
      if(choice.intent?.includes('regain sight'))return animal?'Nose low, the wolf circles toward the last place it saw its prey.':'You were just here. I will find you.';
      if(choice.intent==='flank')return animal?'The wolf circles around, trying to hem its prey in.':'Go around. Make them watch both sides!';
      if(choice.intent==='join pack')return 'The wolf answers its pack with a bark and closes in.';
      if(choice.kind==='crawl')return animal?'The wolf drags itself toward its prey.':'I can still get to you from here!';
      if(profileId==='kobold-scout')return choice.intent==='escape melee'?'Back off. I need room to shoot.':choice.features?.stealthLost?'I need a clearer shot, even if they see me move.':'Better cover. A clearer shot. That is where I need to be.';
      return animal?'The wolf stalks closer, watching for an opening.':'You cannot keep me at a distance!';
    default:return animal?'The creature shifts its weight, ready to act.':'Time to make my move.';
  }
}
