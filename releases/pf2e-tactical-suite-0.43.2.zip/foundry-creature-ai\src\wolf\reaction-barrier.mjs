// Compatibility import for older consumers; the implementation belongs to Core.
export {ReactionBarrier} from '../../../pf2e-tactical-core/src/shared/reaction-barrier.mjs';
