// Only the module's already-resolved movement bypasses the manual drag handler.
export const MANAGED_MOVEMENT = 'foundry-creature-ai:resolved-movement';
export const REQUESTED_MOVEMENT = 'foundry-creature-ai:requested-movement';
