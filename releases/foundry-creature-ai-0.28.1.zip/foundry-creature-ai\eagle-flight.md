# Eagle and shared flight — 0.28.1

The supplied Monster Core Eagle has Beak, agile Talon, fly Speed 60 feet, land Speed 10 feet and two-action Eagle Dive. The adapter binds prepared native attacks and recognizes the compendium provenance. It does not execute text from imported descriptions.

The latest inspected Eagle battle ran the basic NPC fallback under **0.26.3**. Its 21 retained Eagle decisions were 16 Steps and five Strides, with no attacks. Version 0.28.0 replaces that fallback with the Eagle profile. Reload every client and confirm the actual runtime in Alt+W.

## Shared flight

Actors with a prepared fly Speed receive the reusable flight system and default Flight behavior component. Ground movement options are removed while Fly is available. Grounded flyers take off; airborne flyers approach and attack without returning to ground-level movement. Routes include altitude in their state and visitation keys and use native walls, floor surfaces, movement measurement and budget constraints. Current scene-level elevation bounds limit the search; no automatic scene-level switching is introduced.

The native flight cost wrapper applies to Fly movement, including manual native Fly rulers. Moving upward adds the difficult-terrain increment of five feet per square; this preserves alternating diagonal costs and does not stack difficulty twice. Moving straight down costs half. Diagonal descent has its ordinary cost. Previously discounted descent is not discounted again. Environmental terrain still comes through the native cost callback.

The Eagle reserves its last action for Fly when needed to remain aloft, including a zero-distance hover. A committed but constrained Fly still counts as using Fly; the action stays spent and the runner reassesses. Explicit cancellation, unresolved reactions and manual damage retain their pause behavior. Own Fly usage is recorded per combat and round and cleared by prototype reset.

Targets on different elevations in the same scene level can be observed and attacked when native 3D distance, reach, sight and line of effect permit. Reaction geometry uses the same vertical reach; different elevation is no longer an automatic exclusion. Hidden enemies use their known or remembered squares rather than live unseen coordinates.

## Eagle Dive

Dive requires two available actions, a straight flight of no more than twice current fly Speed, at least 10 feet of descent, a clear native route, a legal unoccupied airborne endpoint and a target in Talon reach there. It moves first, then calls the native Talon variant with the current MAP. A stopped activity keeps both actions spent. If its Strike never starts, its known-unused MAP reservation is released. Reactions along a Dive are checked on subdivisions of the same straight line with one shared reaction set.

Approach scoring considers attacks or a Dive using the remaining actions. After attacking, ascending can prepare another pass. The one-time ability showcase preference can make the first Dive more attractive. The AI does not learn target defenses or secret roll outcomes from this evaluation.

## Finish outside melee reach

Shared flight evaluates ordinary melee exposure separately from reaction triggers, even for enemies without Reactive Strike or with spent reactions. The preferred overhead altitude is enemy elevation + body height + maximum prepared melee reach, rounded up to the grid, plus five feet of clearance. A ten-foot-tall enemy at elevation zero with ten-foot reach therefore suggests 25 feet. This clearance is a conservative positioning preference; native attack and reaction legality still use native 3D distance.

After attacking, and especially on the final action, escaping melee exposure competes with another Strike in the same ranking layer. A legal climb above reach is preferred; a blocked climb or low level ceiling can lead to a safe lateral retreat. Existing Fly usage does not disable this retreat. A known safe position can be revisited after an attack rather than rejected as circular movement. Safe flyers penalize approaches or two-action Dives that exhaust their actions in enemy reach. They still approach and attack when an action remains to pull away, and still use Fly to avoid falling.

Safety uses the current observer's target roster and remembered positions, native melee reaches, wall/surface line of effect and bounded native movement. It does not reveal unseen movement or secret check results. Scene levels continue to bound flight; a low level ceiling can prevent the preferred altitude. Ranged attacks and an enemy's future movement can still threaten a flyer outside current melee reach.

The arena Stadium's sole level previously ended at 20 feet. Its upper limit was raised to 60 feet for this flight test; floor elevation and platform surfaces remain as configured. The original level document is backed up in the workspace at `.scratch/stadium-flight-height-before.json`; restoring its `elevation.top` to 20 reverses the headroom change.

## Falling and limits

Death, unconsciousness, paralysis, Prone or losing fly Speed can cause an enabled flying NPC to fall. A conscious eligible flyer with an available shared reaction can attempt native Acrobatics for Arrest a Fall, using DC 15 for ordinary conditions. A successful check prevents falling damage; it does not cancel the landing or remove an existing Prone condition. Landing uses the highest supporting surface beneath the token. Damage is native bludgeoning damage, with native resistance and immunity handling, and damage-taking landings apply Prone once.

Falling into an occupied space pauses for manual falling-on-a-creature resolution and final placement. Special winds, unusual flight maneuvers, cross-level travel, unusually long falls and full volumetric spell areas need further teaching. The current automatic player movement/reaction prompt remains a ground-walking workflow; selecting native Fly receives the cost rules but does not add an automated PC flight action ledger. Flight and Dive reuse the ordinary native Strike, targeting flat-check, damage and Shield Block pipeline.
