import {PF2eBasicNPCAdapter} from './basic-npc-adapter.mjs';
import {attachFlightSystem} from './flight-runtime.mjs';
import {executeFlight} from './flight-execution.mjs';
import {flightCollision,flightMoveTargets,flightPoint,perceivedFlightTarget} from './flight-movement.mjs';
import {flySpeed} from './flight-costs.mjs';
import {flightBounds,isAirborne} from './flight-surfaces.mjs';
import {tokenHeight,tokenAt,volumesOverlap} from './vertical-geometry.mjs';
import {executeNativeStrike} from './native-strikes.mjs';
import {preparedStrikeCandidates} from '../framework/strike-capability.mjs';
import {detectionFor} from './stealth-awareness.mjs';
import {clearSightPath} from './attack-path.mjs';
import {flightThreats,flightSafety} from './flight-safety.mjs';

const ns='foundry-creature-ai',slug=item=>item.slug??item.name.toLowerCase().replaceAll(' ','-');
export const EAGLE_SOURCE='Compendium.pf2e.pathfinder-monster-core.Actor.WBPEvEqIGvxeQKlp';
export class PF2eEagleAdapter extends PF2eBasicNPCAdapter{
  constructor(...args){super(...args);attachFlightSystem(this);}
  get profileId(){return 'eagle';}
  parts(){
    const parts=super.parts(),talon=parts.native.find(strike=>slug(strike.item)==='talon');
    const dive=this.actor.itemTypes.action.find(item=>slug(item)==='eagle-dive'&&item.actionCost?.type==='action'&&item.actionCost.value===2);
    if(!talon||!dive)throw new Error('Eagle requires a prepared Talon Strike and two-action Eagle Dive.');
    return {...parts,talon,dive,abilityNames:[...parts.native.map(s=>s.item.name),`Fly (${flySpeed(this.actor)} ft)`, 'Hover','Eagle Dive (2 actions)','Arrest a Fall','Stand','Escape','Seek'],
      unsupported:parts.unsupported.filter(name=>name!==dive.name)};
  }
  candidates(state){return [...super.candidates(state),...(state.flight?.dives??[])];}
  async enrichFlight(state){
    if(!state.flight?.canFly)return;
    const endpoints=[],bounds=flightBounds(this.token),talon=this.parts().talon;
    const threats=flightThreats(this,state,enemy=>perceivedFlightTarget(this,enemy));
    for(const enemy of state.enemies){
      const target=perceivedFlightTarget(this,enemy),cell=this.cell(target.document);
      for(const elevation of [target.document.elevation,target.document.elevation+tokenHeight(target)])
        for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){
          if(!dx&&!dy||elevation<bounds.bottom||elevation>bounds.top)continue;
          const point={x:cell.x+dx,y:cell.y+dy,elevation},p=flightPoint(this,point),rect=canvas.dimensions.sceneRect;
          if(!isAirborne(this.token,p))continue;
          if(p.x<rect.x||p.y<rect.y||p.x+this.token.w>rect.x+rect.width||p.y+this.token.h>rect.y+rect.height)continue;
          if(canvas.tokens.placeables.some(other=>other!==this.token&&other.actor.hitPoints?.value>0&&
            detectionFor(this.token,other).state==='observed'&&clearSightPath(this.token,other)&&volumesOverlap(tokenAt(this.token,p),other)))continue;
          const positions=flightMoveTargets(this,state,point),geometry=positions[enemy.id].strikes[talon.item.id];
          if(!geometry?.usable)continue;
          const after={...state,enemies:[{...enemy,...positions[enemy.id]}]},strike=preparedStrikeCandidates(after).find(c=>c.strikeId===talon.item.id);
          if(strike)endpoints.push({point,enemyId:enemy.id,value:strike.assessment.value});
        }
    }
    const shown=this.token.document.getFlag(ns,'eagleShown'),showcase=state.style.enabled&&shown?.combatId!==game.combat.id?state.style.showcaseBonus:0;
    const build=(origin,end,actions)=>{
      if(origin.elevation-end.point.elevation<10||!flightCollision(this,flightPoint(this,origin),flightPoint(this,end.point)))return null;
      const points=[flightPoint(this,origin),flightPoint(this,end.point)];
      const cost=this.token.measureMovementPath(this.token.createTerrainMovementPath?.(points,{preview:false})??points).cost;
      if(cost>flySpeed(this.actor)*2)return null;
      const exposedFinish=actions<=2&&!flightSafety(this,flightPoint(this,end.point),threats).safe;
      const retreatPenalty=exposedFinish?state.self.averageDamage*2+2:0;
      const value=end.value+showcase*0.5-retreatPenalty;
      return {id:`eagle-dive:${end.enemyId}:${end.point.x},${end.point.y},${end.point.elevation}`,kind:'eagleDive',legal:true,actionCost:2,mapIncreases:1,
        targetId:end.enemyId,strikeId:talon.item.id,path:[origin,end.point],destination:end.point,movementCost:cost,
        features:{flight:true,dive:true},assessment:{value},
        scoringTerms:[{label:'Talon after a legal descending flight',contribution:end.value},{label:'Show Eagle Dive',contribution:showcase*0.5},
          {label:'No action left to Fly out of melee reach',contribution:-retreatPenalty}]};
    };
    state.flight.dives=state.actionsRemaining>=2?endpoints.map(end=>build(state.flight.origin,end,state.actionsRemaining)).filter(Boolean):[];
    for(const move of state.flight.moves){
      const dive=endpoints.map(end=>build({x:move.x,y:move.y,elevation:move.elevation},end,3)).filter(Boolean);
      // Reserving two actions is required only for a dive during THIS turn.
      // A final ascent after an attack can instead set up the next pass.
      move.diveSetupValue=dive.length&&(state.actionsRemaining>=3||state.attacksMade>0)?Math.max(...dive.map(c=>c.assessment.value))*(state.actionsRemaining>=3?0.9:0.2):0;
    }
  }
  async executeProfileAction(choice,ledger,context){
    if(choice.kind!=='eagleDive')return super.executeProfileAction(choice,ledger,context);
    const movement=await executeFlight(this,choice,ledger,context);
    if(movement.skipped)return movement;
    const target=this.liveTarget(choice.targetId),strike=this.parts().talon;
    if(movement.pause||movement.endTurn||!movement.movement?.arrived||!target||
      !this.targetAt(this.originCell(),target,[],this.actualWaypoint(),strike.item).inReach)
      return {...movement,attackNotAttempted:true};
    const result=await executeNativeStrike(this,strike,target,ledger,context);
    await this.token.document.setFlag(ns,'eagleShown',{combatId:game.combat.id,dive:true});
    return {...movement,...result,note:'Eagle Dive: descend in a straight line, then make one Talon Strike.'};
  }
}
