import {flySpeed} from './flight-costs.mjs';
import {flightMoves} from './flight-movement.mjs';
import {isAirborne} from './flight-surfaces.mjs';
import {executeFlight} from './flight-execution.mjs';
import {resolveFlightFall,flightLost} from './flight-falling.mjs';
import {flightCandidates} from '../framework/flight-candidates.mjs';
import {chooseTacticalAction} from '../framework/tactical-behaviors.mjs';
const attached=new WeakSet(),ns='foundry-creature-ai';
export function attachFlightSystem(adapter){
  if(attached.has(adapter)||!flySpeed(adapter.actor))return adapter;
  attached.add(adapter);
  const snapshot=adapter.snapshot.bind(adapter),candidates=adapter.candidates.bind(adapter),execute=adapter.execute.bind(adapter),prepare=adapter.prepareTurn.bind(adapter);
  adapter.snapshot=async(ledger,options)=>{
    const state=await snapshot(ledger,options),saved=adapter.token.document.getFlag(ns,'flight');
    const canFly=!flightLost(adapter.token)&&!adapter.actor.hasCondition('immobilized','grabbed','restrained');
    state.flight={speed:flySpeed(adapter.actor),airborne:isAirborne(adapter.token),canFly,
      flown:saved?.combatId===game.combat.id&&saved.round===game.combat.round,
      origin:{...adapter.originCell(),elevation:adapter.token.document.elevation},moves:[]};
    if(state.flight.airborne||canFly)state.moves=[];
    if(canFly&&options?.movement!==false)state.flight.moves=flightMoves(adapter,state);
    await adapter.enrichFlight?.(state);
    state.diagnostics.flight={speed:state.flight.speed,airborne:state.flight.airborne,flown:state.flight.flown,reachable:state.flight.moves.length};
    if(state.flight.moves.length){state.diagnostics.movementBlocked=null;state.diagnostics.reachableDestinations=state.flight.moves.length;}
    return state;
  };
  const offered=state=>[...candidates(state),...flightCandidates(state)];
  adapter.candidates=offered;
  adapter.decide=state=>{
    const result=chooseTacticalAction(offered(state),state,{actionsRemaining:state.actionsRemaining,bonusMovementActions:state.bonusMovementActions??0,threatened:state.self.threatened});
    return {...result,diagnostics:{...state.diagnostics,...result.diagnostics,
      ...(result.chosen?.kind==='endTurn'&&state.flight?.canFly&&state.flight.flown?{turnComplete:true}:{} )}};
  };
  adapter.execute=(choice,ledger,context)=>choice.kind==='fly'?executeFlight(adapter,choice,ledger,context):execute(choice,ledger,context);
  adapter.prepareTurn=async(options={})=>{
    if(!adapter.token.document.getFlag(ns,'flight'))await adapter.token.document.setFlag(ns,'flight',{combatId:game.combat.id,round:-1});
    if(flightLost(adapter.token))await resolveFlightFall(adapter.token,{reactions:adapter.reactions,applyDamage:adapter.config.applyDamage});
    return prepare(options);
  };
  return adapter;
}
