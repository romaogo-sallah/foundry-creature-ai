import {preparedStrikeCandidates} from './strike-capability.mjs';
import {PRIORITY} from '../dawnsbury/chooser.mjs';
export function flightCandidates(state){
  const flight=state.flight;
  if(!flight?.canFly||state.actionsRemaining<1)return [];
  const candidates=[];
  if(flight.airborne&&!flight.flown)candidates.push({id:'fly:hover',kind:'fly',legal:true,actionCost:1,path:[flight.origin],destination:flight.origin,
    intent:'hover',features:{flight:true,hover:true},assessment:{value:state.actionsRemaining===1?PRIORITY:0.1},
    scoringTerms:[{label:'Use Fly to remain airborne',contribution:state.actionsRemaining===1?PRIORITY:0.1}]});
  const current=Math.min(...state.enemies.map(enemy=>enemy.distance/5));
  for(const move of flight.moves??[]){
    if(!move.airborne)continue;
    const key=`${move.x},${move.y},${move.elevation}`;
    if(state.visited?.includes(key))continue;
    const next={...state,actionsRemaining:state.actionsRemaining-1,enemies:state.enemies.map(enemy=>({...enemy,...move.targets[enemy.id]}))};
    const attacks=preparedStrikeCandidates(next),follow=Math.max(0,...attacks.map(c=>c.assessment.value));
    const progress=Math.max(0,current-move.nearestEnemy)*0.15;
    const setup=move.diveSetupValue??0,reset=state.attacksMade>0&&move.elevation>flight.origin.elevation&&setup>0?0.6:0;
    const exposure=move.destinationThreatened?0.25:0,maintenance=flight.airborne&&!flight.flown&&state.actionsRemaining===1?0.25:0;
    const losesSight=state.enemies.some(enemy=>enemy.lineOfSight!==false)&&state.enemies.every(enemy=>move.targets[enemy.id]?.lineOfSight===false);
    const sightPenalty=losesSight?Math.max(2,state.self.averageDamage):0;
    const value=Math.max(follow,setup)+progress+reset+maintenance-(move.reactionRisk??0)-exposure-sightPenalty;
    if(value<=0&&flight.airborne)continue;
    candidates.push({id:`fly:${key}`,kind:'fly',legal:true,actionCost:1,path:move.path,destination:{x:move.x,y:move.y,elevation:move.elevation},
      movementCost:move.cost,provokes:move.provokes,destinationThreatened:move.destinationThreatened,
      intent:!flight.airborne?'take off and approach':setup>follow?'gain height for a dive':move.nearestEnemy<current?'approach in flight':'reposition in flight',
      features:{flight:true,diveSetup:setup>follow},assessment:{value:Math.max(0.01,value),movement:true,goodAttacksLeft:follow>0||setup>0&&state.actionsRemaining>=3,
        nearestEnemy:move.nearestEnemy,currentNearestEnemy:current,distanceMoved:move.cost/5,reachSquares:state.self.reachSquares},
      scoringTerms:[{label:'Attack or dive after flight',contribution:Math.max(follow,setup)},
        {label:'Approach and prepare another pass',contribution:progress+reset+maintenance},
        {label:'Known reaction, lost sight and destination exposure',contribution:-(move.reactionRisk??0)-exposure-sightPenalty}]});
  }
  return candidates;
}
